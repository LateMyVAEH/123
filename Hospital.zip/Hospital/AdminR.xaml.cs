﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital
{
    /// <summary>
    /// Логика взаимодействия для AdminR.xaml
    /// </summary>
    public partial class AdminR : Window
    {
        public AdminR()
        {
            InitializeComponent();
            UpdateRegistration();
        }
        public void UpdateRegistration()
        {
            var list = App.DBSQLP.Registration.ToList();
            Registration Reg = new Registration();
            listView.ItemsSource = list;
        }

        private void Registration_Click(object sender, RoutedEventArgs e)
        {
            MainWindow Registration = new MainWindow();
            Registration.Show();
            this.Close();
        }

        private void Registration_Click_1(object sender, RoutedEventArgs e)
        {
            RegistrationAdm Registration = new RegistrationAdm();
            Registration.Show();
            this.Close();
        }

        private void GotoReception_Click(object sender, RoutedEventArgs e)
        {
            Reception Registration = new Reception();
            Registration.Show();
            this.Close();
        }
    }
}
