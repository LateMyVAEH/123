﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital
{
    public partial class RegistrationAdm : Window
    {
        public RegistrationAdm()
        {
            InitializeComponent();
            Update();
        }
        public void Update()
        {
            var list = App.DBSQLP.Registration.ToList();
            Registration Reg = new Registration();
            listView.ItemsSource = list;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AdminR GotoMain = new AdminR();
            GotoMain.Show();
            this.Close();
        }
        private void ADD_Click(object sender, RoutedEventArgs e)
        {
            Registration ADDR = new Registration
            {
                Name = NameR.ToString(),
                Surname = SurnameR.ToString(),
                Patronimic = PatronimicR.ToString(),
                Passport = Convert.ToInt32(PassportR.Text),
                Snils = Convert.ToInt32(SnilsR.Text),
                Telephone = Convert.ToInt32(TelephoneR.Text),
                IssuedByWhom = dateIssuedBy.ToString(),
                //WhenIssued = dateIssuedBy,
                /*SelectedDates.Value.Date.ToShortDateString(),*/
            };
            App.DBSQLP.Registration.Add(ADDR);
            App.DBSQLP.SaveChanges();
            Update();
        }
        private void SnilsR_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
        private void TextBlock_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
        private void issuedbywhenR_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
        private void idRoleR_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
        private void PassportR_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
        private void DELETE_Click(object sender, RoutedEventArgs e)
        {
            Button DeleteButton = (Button)sender;
            Registration DeleteHeroes = (Registration)DeleteButton.DataContext;
            App.DBSQLP.Registration.Remove(DeleteHeroes);
            App.DBSQLP.SaveChanges();
            Update();
        }
        private void Edit_Click(object sender, RoutedEventArgs e) 
        {
            int pass = Convert.ToInt32(PassportR.Text);
            int sn = Convert.ToInt32(SnilsR.Text);
            int phone = Convert.ToInt32(TelephoneR.Text);
            Button EDITButton = (Button)sender;
            Registration EDITReg = (Registration)EDITButton.DataContext;
            NameR.Text = EDITReg.Name;
            SurnameR.Text = EDITReg.Surname;
            PatronimicR.Text = EDITReg.Patronimic;
            pass = EDITReg.Passport;
            sn = EDITReg.Snils;
            phone = EDITReg.Telephone;
            //issuedbywhenR.Text = EDITReg.IssuedByWhom;
            //whenissued.Text = EDITReg.WhenIssued;
            //ComboID.Text = EDITReg.idRoles;
            App.DBSQLP.SaveChanges();
            Update();
        }
        private void ComboID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        public void Update_ComboBox()
        {
            var listview = App.DBSQLP.Registration;
            var list = listView.ToList();
            List<string> variir = new List<string>();
            variir.Add("All");
            foreach(var item in list)
            {
                variir.Add(item.Name);
            }
            Category_ComboBox.ItemsSource = variir;
        }
    }
}
